-- =====================================================================
-- WABA Service — Dummy / Seed Data for Development & Testing
-- =====================================================================
-- Schema version : waba_v1.sql
-- Excluded tables : pinacle_credentials, pinacle_billing_config,
--                   pinacle_credit_ledger, pinacle_credit_line_attachments
-- All waba_accounts use onboarding_provider = 'META_DIRECT'
--
-- Run AFTER waba_v1.sql on a clean database:
--   mysql -u root -p apargo_wa_messaging < dummy_data.sql
-- =====================================================================

USE apargo_wa_waba;

-- =====================================================================
-- 1. meta_oauth_tokens  (3 organizations)
-- =====================================================================
-- Covers: findByOrganizationId, different token_type values,
--         long-lived (no expiry) vs short-lived tokens,
--         soft-deleted token for org 3.
-- =====================================================================
INSERT INTO meta_oauth_tokens
    (id, organization_id, access_token, expires_at, meta_user_id,
     system_user_id, business_manager_id, granted_scopes, granted_at,
     token_type, created_at, updated_at, deleted_at)
VALUES
    -- Org 1001: Active user token, expires in future
    (1, 1001,
     'EAAIzBQ5ZCLz4BAEncrypted_Token_Org1001_Active',
     '2027-06-30 23:59:59.000000',
     'meta_user_100001', NULL, 'bm_900001',
     'whatsapp_business_management,whatsapp_business_messaging,business_management',
     '2026-01-15 10:30:00.000000',
     'USER_TOKEN',
     '2026-01-15 10:30:00.000000', '2026-01-15 10:30:00.000000', NULL),

    -- Org 1002: Active system-user token, never expires
    (2, 1002,
     'EAAIzBQ5ZCLz4BAEncrypted_Token_Org1002_SystemUser',
     NULL,
     NULL, 'sys_user_200001', 'bm_900002',
     'whatsapp_business_management,whatsapp_business_messaging',
     '2025-11-01 08:00:00.000000',
     'SYSTEM_USER',
     '2025-11-01 08:00:00.000000', '2025-11-01 08:00:00.000000', NULL),

    -- Org 1003: Soft-deleted token (org disconnected)
    (3, 1003,
     'EAAIzBQ5ZCLz4BAEncrypted_Token_Org1003_Deleted',
     '2026-12-31 23:59:59.000000',
     'meta_user_300001', NULL, 'bm_900003',
     'whatsapp_business_management,whatsapp_business_messaging',
     '2025-06-01 14:00:00.000000',
     'USER_TOKEN',
     '2025-06-01 14:00:00.000000', '2026-04-20 09:00:00.000000',
     '2026-04-20 09:00:00.000000');


-- =====================================================================
-- 2. waba_accounts  (5 WABAs across 2 active orgs)
-- =====================================================================
-- Covers: findByWabaId, findByOrganizationId, findByOrganizationIdAndStatus,
--         findByBusinessManagerId, various status / review / verification combos.
-- All META_DIRECT → meta_oauth_token_id set, bsp_credential_id NULL.
-- =====================================================================
INSERT INTO waba_accounts
    (id, organization_id, onboarding_provider, meta_oauth_token_id,
     bsp_credential_id, waba_id, business_manager_id, status,
     account_review_status, business_verification_status,
     message_template_namespace, timezone_id, currency,
     created_at, updated_at, deleted_at)
VALUES
    -- Org 1001, WABA-A: fully verified, active, production-ready
    (1, 1001, 'META_DIRECT', 1, NULL,
     'waba_1001_a', 'bm_900001', 'ACTIVE',
     'APPROVED', 'VERIFIED',
     'ns_waba_1001_a', 'Asia/Kolkata', 'INR',
     '2026-01-20 11:00:00.000000', '2026-07-01 12:00:00.000000', NULL),

    -- Org 1001, WABA-B: active but business verification pending
    (2, 1001, 'META_DIRECT', 1, NULL,
     'waba_1001_b', 'bm_900001', 'ACTIVE',
     'PENDING', 'PENDING',
     'ns_waba_1001_b', 'Asia/Kolkata', 'INR',
     '2026-03-10 09:00:00.000000', '2026-03-10 09:00:00.000000', NULL),

    -- Org 1001, WABA-C: suspended account (spam detected)
    (3, 1001, 'META_DIRECT', 1, NULL,
     'waba_1001_c', 'bm_900001', 'SUSPENDED',
     'DISABLED', 'VERIFIED',
     'ns_waba_1001_c', 'Asia/Kolkata', 'INR',
     '2026-02-01 08:00:00.000000', '2026-05-15 16:00:00.000000', NULL),

    -- Org 1002, WABA-D: active, different BM, USD currency
    (4, 1002, 'META_DIRECT', 2, NULL,
     'waba_1002_d', 'bm_900002', 'ACTIVE',
     'APPROVED', 'VERIFIED',
     'ns_waba_1002_d', 'America/New_York', 'USD',
     '2025-12-01 10:00:00.000000', '2026-06-01 10:00:00.000000', NULL),

    -- Org 1002, WABA-E: disconnected, soft-deleted
    (5, 1002, 'META_DIRECT', 2, NULL,
     'waba_1002_e', 'bm_900002', 'DISCONNECTED',
     'REJECTED', 'NOT_VERIFIED',
     NULL, 'America/New_York', 'USD',
     '2025-11-15 12:00:00.000000', '2026-04-01 09:00:00.000000',
     '2026-04-01 09:00:00.000000');


-- =====================================================================
-- 3. waba_phone_numbers  (8 phone numbers across WABAs)
-- =====================================================================
-- Covers: findByWhatsappPhoneNumberId, findByWabaAccountId,
--         canSendMessages(), hasPoorQuality(), isOfficialBusinessAccount(),
--         all enum values coverage.
-- =====================================================================
INSERT INTO waba_phone_numbers
    (id, waba_account_id, phone_number_id, display_phone_number, status,
     verified_name, quality_rating, messaging_limit_tier,
     messaging_throughput_tier, name_status, health_status,
     is_official_business_account, code_verification_status,
     created_at, updated_at, deleted_at)
VALUES
    -- WABA 1 (Org 1001-A): 3 phone numbers, production quality
    (1, 1, 'pn_10010001', '+91 98765 43210', 'ACTIVE',
     'Apargo Technologies', 'GREEN', 'LIMIT_100K',
     'HIGH', 'APPROVED', 'GREEN',
     TRUE, 'VERIFIED',
     '2026-01-20 12:00:00.000000', '2026-07-01 12:00:00.000000', NULL),

    (2, 1, 'pn_10010002', '+91 98765 43211', 'ACTIVE',
     'Apargo Support', 'GREEN', 'LIMIT_10K',
     'STANDARD', 'APPROVED', 'GREEN',
     FALSE, 'VERIFIED',
     '2026-02-15 10:00:00.000000', '2026-06-20 14:00:00.000000', NULL),

    (3, 1, 'pn_10010003', '+91 98765 43212', 'PENDING',
     NULL, 'UNKNOWN', 'LIMIT_250',
     'STANDARD', 'PENDING', 'UNKNOWN',
     FALSE, 'PENDING',
     '2026-07-01 09:00:00.000000', '2026-07-01 09:00:00.000000', NULL),

    -- WABA 2 (Org 1001-B): 1 phone, fresh onboarding
    (4, 2, 'pn_10010004', '+91 87654 32100', 'ACTIVE',
     'Apargo Marketing', 'YELLOW', 'LIMIT_2K',
     'STANDARD', 'APPROVED', 'YELLOW',
     FALSE, 'VERIFIED',
     '2026-03-10 10:00:00.000000', '2026-06-15 11:00:00.000000', NULL),

    -- WABA 3 (Org 1001-C, SUSPENDED): 1 phone, RED quality
    (5, 3, 'pn_10010005', '+91 76543 21000', 'BLOCKED',
     'Apargo Promo', 'RED', 'LIMIT_250',
     'STANDARD', 'REJECTED', 'RED',
     FALSE, 'VERIFIED',
     '2026-02-01 09:00:00.000000', '2026-05-15 16:00:00.000000', NULL),

    -- WABA 4 (Org 1002-D): 2 phone numbers, US org
    (6, 4, 'pn_10020001', '+1 555-012-3456', 'ACTIVE',
     'Acme Corp', 'GREEN', 'LIMIT_UNLIMITED',
     'HIGH', 'APPROVED', 'GREEN',
     TRUE, 'VERIFIED',
     '2025-12-01 11:00:00.000000', '2026-06-01 10:00:00.000000', NULL),

    (7, 4, 'pn_10020002', '+1 555-012-3457', 'ACTIVE',
     'Acme Support', 'GREEN', 'LIMIT_10K',
     'STANDARD', 'AVAILABLE_WITHOUT_REVIEW', 'GREEN',
     FALSE, 'VERIFIED',
     '2026-01-10 08:00:00.000000', '2026-05-20 09:00:00.000000', NULL),

    -- WABA 5 (Org 1002-E, DISCONNECTED): 1 phone, disabled
    (8, 5, 'pn_10020003', '+1 555-012-3458', 'DISABLED',
     'Acme Old', 'RED', 'LIMIT_250',
     'STANDARD', 'PENDING_DELETION', 'BLOCKED',
     FALSE, 'EXPIRED',
     '2025-11-15 13:00:00.000000', '2026-04-01 09:00:00.000000',
     '2026-04-01 09:00:00.000000');


-- =====================================================================
-- 4. waba_daily_message_usage  (30 days of data for WABA 1 & 4)
-- =====================================================================
-- Covers: findByWabaAccountIdAndUsageDate,
--         findByWabaAccountIdAndUsageDateBetween,
--         findByWabaAccountIdInAndUsageDate,
--         findByUsageDateBefore (old data for archival testing).
-- =====================================================================
INSERT INTO waba_daily_message_usage
    (id, waba_account_id, usage_date, messages_sent,
     created_at, updated_at, deleted_at)
VALUES
    -- ---- WABA 1 (Org 1001-A): June 2026 daily data ----
    ( 1, 1, '2026-06-01',  1200, '2026-06-01 23:59:00.000000', '2026-06-01 23:59:00.000000', NULL),
    ( 2, 1, '2026-06-02',  1350, '2026-06-02 23:59:00.000000', '2026-06-02 23:59:00.000000', NULL),
    ( 3, 1, '2026-06-03',  1100, '2026-06-03 23:59:00.000000', '2026-06-03 23:59:00.000000', NULL),
    ( 4, 1, '2026-06-04',   980, '2026-06-04 23:59:00.000000', '2026-06-04 23:59:00.000000', NULL),
    ( 5, 1, '2026-06-05',  1500, '2026-06-05 23:59:00.000000', '2026-06-05 23:59:00.000000', NULL),
    ( 6, 1, '2026-06-06',   400, '2026-06-06 23:59:00.000000', '2026-06-06 23:59:00.000000', NULL),
    ( 7, 1, '2026-06-07',   350, '2026-06-07 23:59:00.000000', '2026-06-07 23:59:00.000000', NULL),
    ( 8, 1, '2026-06-08',  1450, '2026-06-08 23:59:00.000000', '2026-06-08 23:59:00.000000', NULL),
    ( 9, 1, '2026-06-09',  1600, '2026-06-09 23:59:00.000000', '2026-06-09 23:59:00.000000', NULL),
    (10, 1, '2026-06-10',  1750, '2026-06-10 23:59:00.000000', '2026-06-10 23:59:00.000000', NULL),
    (11, 1, '2026-06-11',  2100, '2026-06-11 23:59:00.000000', '2026-06-11 23:59:00.000000', NULL),
    (12, 1, '2026-06-12',  2300, '2026-06-12 23:59:00.000000', '2026-06-12 23:59:00.000000', NULL),
    (13, 1, '2026-06-13',   500, '2026-06-13 23:59:00.000000', '2026-06-13 23:59:00.000000', NULL),
    (14, 1, '2026-06-14',   420, '2026-06-14 23:59:00.000000', '2026-06-14 23:59:00.000000', NULL),
    (15, 1, '2026-06-15',  1800, '2026-06-15 23:59:00.000000', '2026-06-15 23:59:00.000000', NULL),

    -- ---- WABA 4 (Org 1002-D): June 2026 daily data ----
    (16, 4, '2026-06-01',  5400, '2026-06-01 23:59:00.000000', '2026-06-01 23:59:00.000000', NULL),
    (17, 4, '2026-06-02',  5200, '2026-06-02 23:59:00.000000', '2026-06-02 23:59:00.000000', NULL),
    (18, 4, '2026-06-03',  5800, '2026-06-03 23:59:00.000000', '2026-06-03 23:59:00.000000', NULL),
    (19, 4, '2026-06-04',  4900, '2026-06-04 23:59:00.000000', '2026-06-04 23:59:00.000000', NULL),
    (20, 4, '2026-06-05',  6100, '2026-06-05 23:59:00.000000', '2026-06-05 23:59:00.000000', NULL),
    (21, 4, '2026-06-06',  2000, '2026-06-06 23:59:00.000000', '2026-06-06 23:59:00.000000', NULL),
    (22, 4, '2026-06-07',  1800, '2026-06-07 23:59:00.000000', '2026-06-07 23:59:00.000000', NULL),
    (23, 4, '2026-06-08',  5500, '2026-06-08 23:59:00.000000', '2026-06-08 23:59:00.000000', NULL),
    (24, 4, '2026-06-09',  5700, '2026-06-09 23:59:00.000000', '2026-06-09 23:59:00.000000', NULL),
    (25, 4, '2026-06-10',  6200, '2026-06-10 23:59:00.000000', '2026-06-10 23:59:00.000000', NULL),

    -- ---- WABA 2 (Org 1001-B): low volume, only a few days ----
    (26, 2, '2026-06-10',   45, '2026-06-10 23:59:00.000000', '2026-06-10 23:59:00.000000', NULL),
    (27, 2, '2026-06-11',   62, '2026-06-11 23:59:00.000000', '2026-06-11 23:59:00.000000', NULL),
    (28, 2, '2026-06-12',   38, '2026-06-12 23:59:00.000000', '2026-06-12 23:59:00.000000', NULL),

    -- ---- OLD DATA for archival testing (findByUsageDateBefore) ----
    (29, 1, '2025-12-01',   200, '2025-12-01 23:59:00.000000', '2025-12-01 23:59:00.000000', NULL),
    (30, 1, '2025-12-15',   310, '2025-12-15 23:59:00.000000', '2025-12-15 23:59:00.000000', NULL),
    (31, 4, '2025-12-01',   900, '2025-12-01 23:59:00.000000', '2025-12-01 23:59:00.000000', NULL);


-- =====================================================================
-- 5. project_waba_assignments  (6 assignments across 4 projects)
-- =====================================================================
-- Covers: findByProjectId, findByWabaAccountId,
--         findByProjectIdAndDefaultAssignmentTrue,
--         multi-WABA per project, default flag, custom_daily_limit.
-- =====================================================================
INSERT INTO project_waba_assignments
    (id, project_id, waba_account_id, is_default, custom_daily_limit,
     created_at, updated_at, deleted_at)
VALUES
    -- Project 5001 → WABA 1 (default, 50K limit) + WABA 2 (non-default, no limit)
    (1, 5001, 1, TRUE,  50000,
     '2026-02-01 10:00:00.000000', '2026-02-01 10:00:00.000000', NULL),
    (2, 5001, 2, FALSE, NULL,
     '2026-03-15 10:00:00.000000', '2026-03-15 10:00:00.000000', NULL),

    -- Project 5002 → WABA 1 only (default, 20K limit)
    (3, 5002, 1, TRUE,  20000,
     '2026-02-10 11:00:00.000000', '2026-02-10 11:00:00.000000', NULL),

    -- Project 5003 → WABA 4 (default, unlimited)
    (4, 5003, 4, TRUE,  NULL,
     '2026-01-05 09:00:00.000000', '2026-01-05 09:00:00.000000', NULL),

    -- Project 5004 → WABA 4 (default, 10K limit) + WABA 1 cross-org usage (non-default)
    (5, 5004, 4, TRUE,  10000,
     '2026-03-01 08:00:00.000000', '2026-03-01 08:00:00.000000', NULL),
    (6, 5004, 1, FALSE, 5000,
     '2026-04-01 08:00:00.000000', '2026-04-01 08:00:00.000000', NULL);


-- =====================================================================
-- 6. onboarding_tasks  (6 tasks — all META_DIRECT provider)
-- =====================================================================
-- Covers: findByIdempotencyKey, findByOrganizationId,
--         findByOrganizationIdAndStatus,
--         all OnboardingStatus values, various current_step values,
--         completed vs failed vs in-progress flows.
-- =====================================================================
INSERT INTO onboarding_tasks
    (id, organization_id, project_id, provider, oauth_code, status,
     current_step, retry_count, idempotency_key,
     encrypted_access_token, token_expires_in,
     resolved_waba_id, resolved_business_manager_id,
     resolved_phone_number_id, result_waba_account_id,
     completed_steps, result_summary, error_message,
     started_at, finished_at,
     created_at, updated_at, deleted_at)
VALUES
    -- Task 1: COMPLETED — Org 1001, full successful onboarding
    (1, 1001, 5001, 'META_DIRECT',
     'AQDfake_oauth_code_org1001_task1', 'COMPLETED',
     'PHONE_REGISTRATION', 0,
     'idem_1001_20260120_001',
     'EAAIzBQ5ZCLz4BAEncrypted_Onboarding_Token_1', 5184000,
     'waba_1001_a', 'bm_900001', 'pn_10010001', 1,
     '["TOKEN_EXCHANGE","TOKEN_EXTENSION","SCOPE_VERIFICATION","BUSINESS_MANAGER_RESOLUTION","WABA_RESOLUTION","PHONE_NUMBER_RESOLUTION","CREDENTIAL_PERSISTENCE","WEBHOOK_SUBSCRIPTION","PHONE_SYNC","PHONE_REGISTRATION"]',
     '{"waba_id":"waba_1001_a","phone_numbers_synced":1,"webhooks_subscribed":true}',
     NULL,
     '2026-01-20 11:00:00.000000', '2026-01-20 11:05:32.000000',
     '2026-01-20 11:00:00.000000', '2026-01-20 11:05:32.000000', NULL),

    -- Task 2: COMPLETED — Org 1001, second WABA onboarding
    (2, 1001, 5001, 'META_DIRECT',
     'AQDfake_oauth_code_org1001_task2', 'COMPLETED',
     'PHONE_REGISTRATION', 0,
     'idem_1001_20260310_002',
     'EAAIzBQ5ZCLz4BAEncrypted_Onboarding_Token_2', 5184000,
     'waba_1001_b', 'bm_900001', 'pn_10010004', 2,
     '["TOKEN_EXCHANGE","TOKEN_EXTENSION","SCOPE_VERIFICATION","BUSINESS_MANAGER_RESOLUTION","WABA_RESOLUTION","PHONE_NUMBER_RESOLUTION","CREDENTIAL_PERSISTENCE","WEBHOOK_SUBSCRIPTION","PHONE_SYNC","PHONE_REGISTRATION"]',
     '{"waba_id":"waba_1001_b","phone_numbers_synced":1,"webhooks_subscribed":true}',
     NULL,
     '2026-03-10 09:00:00.000000', '2026-03-10 09:04:50.000000',
     '2026-03-10 09:00:00.000000', '2026-03-10 09:04:50.000000', NULL),

    -- Task 3: FAILED — Org 1001, scope verification failure after 3 retries
    (3, 1001, NULL, 'META_DIRECT',
     'AQDfake_oauth_code_org1001_task3_fail', 'FAILED',
     'SCOPE_VERIFICATION', 3,
     'idem_1001_20260501_003',
     'EAAIzBQ5ZCLz4BAEncrypted_Onboarding_Token_3', 5184000,
     NULL, NULL, NULL, NULL,
     '["TOKEN_EXCHANGE","TOKEN_EXTENSION"]',
     NULL,
     'Missing required scope: whatsapp_business_messaging. User granted only whatsapp_business_management.',
     '2026-05-01 14:00:00.000000', '2026-05-01 14:01:15.000000',
     '2026-05-01 14:00:00.000000', '2026-05-01 14:01:15.000000', NULL),

    -- Task 4: PROCESSING — Org 1002, currently mid-onboarding
    (4, 1002, 5003, 'META_DIRECT',
     'AQDfake_oauth_code_org1002_task4', 'PROCESSING',
     'WEBHOOK_SUBSCRIPTION', 1,
     'idem_1002_20260715_004',
     'EAAIzBQ5ZCLz4BAEncrypted_Onboarding_Token_4', 5184000,
     'waba_1002_new', 'bm_900002', NULL, NULL,
     '["TOKEN_EXCHANGE","TOKEN_EXTENSION","SCOPE_VERIFICATION","BUSINESS_MANAGER_RESOLUTION","WABA_RESOLUTION","PHONE_NUMBER_RESOLUTION","CREDENTIAL_PERSISTENCE"]',
     NULL, NULL,
     '2026-07-15 10:00:00.000000', NULL,
     '2026-07-15 10:00:00.000000', '2026-07-15 10:02:30.000000', NULL),

    -- Task 5: PENDING — Org 1002, queued but not started
    (5, 1002, 5004, 'META_DIRECT',
     'AQDfake_oauth_code_org1002_task5', 'PENDING',
     NULL, 0,
     'idem_1002_20260720_005',
     NULL, NULL,
     NULL, NULL, NULL, NULL,
     NULL, NULL, NULL,
     NULL, NULL,
     '2026-07-20 08:00:00.000000', '2026-07-20 08:00:00.000000', NULL),

    -- Task 6: CANCELLED — Org 1001, user cancelled mid-flow
    (6, 1001, 5002, 'META_DIRECT',
     'AQDfake_oauth_code_org1001_task6_cancel', 'CANCELLED',
     'WABA_RESOLUTION', 0,
     'idem_1001_20260601_006',
     'EAAIzBQ5ZCLz4BAEncrypted_Onboarding_Token_6', 5184000,
     NULL, 'bm_900001', NULL, NULL,
     '["TOKEN_EXCHANGE","TOKEN_EXTENSION","SCOPE_VERIFICATION","BUSINESS_MANAGER_RESOLUTION"]',
     NULL,
     'Cancelled by user before WABA resolution completed.',
     '2026-06-01 16:00:00.000000', '2026-06-01 16:02:00.000000',
     '2026-06-01 16:00:00.000000', '2026-06-01 16:02:00.000000', NULL);


-- =====================================================================
-- Quick verification queries (uncomment to run)
-- =====================================================================
-- SELECT 'meta_oauth_tokens'   AS tbl, COUNT(*) AS cnt FROM meta_oauth_tokens
-- UNION ALL
-- SELECT 'waba_accounts',       COUNT(*) FROM waba_accounts
-- UNION ALL
-- SELECT 'waba_phone_numbers',  COUNT(*) FROM waba_phone_numbers
-- UNION ALL
-- SELECT 'waba_daily_usage',    COUNT(*) FROM waba_daily_message_usage
-- UNION ALL
-- SELECT 'project_assignments', COUNT(*) FROM project_waba_assignments
-- UNION ALL
-- SELECT 'onboarding_tasks',    COUNT(*) FROM onboarding_tasks;